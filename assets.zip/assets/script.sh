rm ./png/*
for pasta in backs clubs diamonds hearts spades;
do
	for i in $pasta/*;
	do
		filename=$(basename "$i")
		extension="${filename##*.}"
		filename="${filename%.*}"
		inkscape -z -f $i -w 150 -j -e png/$filename.png
	done
done
cd png
rename "s/A/1/g" A*.png
rename "s/J/11/g" J*.png
rename "s/Q/12/g" Q*.png
rename "s/K/13/g" K*.png

